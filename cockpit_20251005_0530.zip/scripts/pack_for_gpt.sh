#!/usr/bin/env bash
set -euo pipefail

ROOT="$(pwd)"
DATE=$(date +"%Y%m%d_%H%M")
OUT_ENV="$ROOT/env_report_$DATE"
ZIP_ENV="$ROOT/env_report_$DATE.zip"
ZIP_CODE="$ROOT/cockpit_$DATE.zip"

echo "==> Ensuring utilities (zip, jq, ripgrep) are available..."
if ! command -v zip >/dev/null 2>&1 || ! command -v jq >/dev/null 2>&1 || ! command -v rg >/dev/null 2>&1; then
  sudo apt-get update -y >/dev/null 2>&1 || true
fi
command -v zip >/dev/null 2>&1 || sudo apt-get install -y zip >/dev/null 2>&1 || true
command -v jq  >/dev/null 2>&1 || sudo apt-get install -y jq  >/dev/null 2>&1 || true
command -v rg  >/dev/null 2>&1 || sudo apt-get install -y ripgrep >/dev/null 2>&1 || true

echo "==> Building environment report at $OUT_ENV ..."
mkdir -p "$OUT_ENV"

# system info
{
  echo "# System"
  date -Is
  uname -a || true
  echo
  echo "## /etc/os-release"
  cat /etc/os-release 2>/dev/null || true
  echo
  echo "## CPU & Memory"
  lscpu 2>/dev/null || true
  free -h 2>/dev/null || true
  df -h 2>/dev/null || true
} > "$OUT_ENV/system.txt"

# tooling
{
  command -v node && node -v
  command -v npm && npm -v
  command -v pnpm && pnpm -v || true
  command -v bun && bun -v || true
  npx --yes next --version 2>/dev/null || true
  npx --yes tsc -v 2>/dev/null || true
  npx --yes vitest --version 2>/dev/null || true
  npx --yes jest --version 2>/dev/null || true
  npx --yes prisma -v 2>/dev/null || true
} > "$OUT_ENV/tooling.txt"

# package.json
if [[ -f "$ROOT/package.json" ]]; then
  cp package.json "$OUT_ENV/"
  node -e 'const fs=require("fs");const p=require("./package.json");fs.writeFileSync(process.argv[1],JSON.stringify({scripts:p.scripts||{},dependencies:p.dependencies||{},devDependencies:p.devDependencies||{}},null,2))' "$OUT_ENV/package_scripts_deps.json"
fi

# config files
for f in next.config.js tsconfig.json jest.config.js vitest.config.ts tailwind.config.js postcss.config.js; do
  [[ -f "$f" ]] && cp "$f" "$OUT_ENV/"
done

# prisma
if [[ -f "$ROOT/prisma/schema.prisma" ]]; then
  mkdir -p "$OUT_ENV/prisma"
  cp prisma/schema.prisma "$OUT_ENV/prisma/"
  npx --yes prisma migrate status > "$OUT_ENV/prisma_migrate_status.txt" 2>&1 || true
fi

# db scan (masked)
{
  rg -n --hidden --glob ".env*" 'DATABASE_URL|DB_|POSTGRES|MYSQL|SQLITE|SUPABASE|MONGODB' || true
  rg -n 'datasource|provider|url' prisma/schema.prisma 2>/dev/null || true
} | sed -E 's#(=)[^ \t\r\n]+#=\*\*\*\*#g' > "$OUT_ENV/db_endpoints.txt"

# env vars masked
printenv | sort | sed -E 's#(^[^=]*(TOKEN|SECRET|PASSWORD|KEY|API|DB|DATABASE|URL)[^=]*=).*#\1****#I' > "$OUT_ENV/env_public.txt"

# ports & processes
(ss -tulpn 2>/dev/null || true) > "$OUT_ENV/ports.txt"
(ps aux --sort=-%mem 2>/dev/null | head -n 60 || true) > "$OUT_ENV/processes_top.txt"

# repo map
ls -al > "$OUT_ENV/repo_top_level.txt"

# .env.share template
if [[ -f ".env.example" ]]; then
  cp .env.example "$OUT_ENV/.env.share"
else
  {
    rg -n -o --glob 'src/**' 'process\.env\.[A-Z0-9_]+' | sed -E 's/.*process\.env\.//' 
  } | sort -u | awk '{print $0"="}' > "$OUT_ENV/.env.share" || true
fi

# readme for gpt
cat > "$OUT_ENV/README_SHARE_WITH_GPT.md" <<'MD'
Upload this folder with your code so GPT understands your environment:
- system.txt, tooling.txt
- package.json, package_scripts_deps.json
- configs (tsconfig, next.config, tailwind, jest, vitest)
- prisma schema/migrations (if any)
- masked env + db endpoints
- ports/processes
MD

# zip environment
zip -r "$ZIP_ENV" "$(basename $OUT_ENV)" >/dev/null

# zip code
zip -r "$ZIP_CODE" \
  src public docs scripts prisma tests \
  *.md *.js *.ts *.json *.yaml *.yml \
  next.config.js tailwind.config.js postcss.config.js jest.config.js vitest.config.ts \
  --exclude "node_modules/*" ".git/*" ".next/*" ".vscode/*" ".github/*" ".vercel/*" \
            "*.log" "*.tsbuildinfo" ".env*" "build-output.log" "test-output.log" "temp.json" "latestEnd" >/dev/null

echo "==> Code bundle: $ZIP_CODE"
unzip -l "$ZIP_CODE" | head -n 30
echo "==> Env bundle: $ZIP_ENV"
unzip -l "$ZIP_ENV" | head -n 30
