import { ResourcePlanningShell } from '@/components/resource-planning';

export default function ResourcePlanningPage() {
  return <ResourcePlanningShell />;
}