#!/usr/bin/env bash
set -euo pipefail

ROOT="$(pwd)"
DATE="$(date +"%Y%m%d_%H%M")"

OUT_DIR="$ROOT/gptdebug"
OUT_ENV_DIR="$OUT_DIR/env_report_$DATE"
ZIP_CODE="$OUT_DIR/cockpit_$DATE.zip"
ZIP_ENV="$OUT_DIR/env_report_$DATE.zip"

echo "==> Ensuring utilities (zip, jq, ripgrep) are available..."
need_update=0
for bin in zip jq rg; do
  if ! command -v "$bin" >/dev/null 2>&1; then need_update=1; fi
done
if [ "$need_update" -eq 1 ]; then
  sudo apt-get update -y >/dev/null 2>&1 || true
  command -v zip >/dev/null 2>&1 || sudo apt-get install -y zip >/dev/null 2>&1 || true
  command -v jq  >/dev/null 2>&1 || sudo apt-get install -y jq  >/dev/null 2>&1 || true
  command -v rg  >/dev/null 2>&1 || sudo apt-get install -y ripgrep >/dev/null 2>&1 || true
fi

echo "==> Preparing output folders in $OUT_DIR ..."
mkdir -p "$OUT_DIR" "$OUT_ENV_DIR"

echo "==> Collecting system info ..."
{
  echo "# System"
  date -Is
  uname -a || true
  echo
  echo "## /etc/os-release"
  cat /etc/os-release 2>/dev/null || true
  echo
  echo "## CPU & Memory"
  lscpu 2>/dev/null || true
  echo
  free -h 2>/dev/null || true
  echo
  echo "## Disks"
  df -h 2>/dev/null || true
} > "$OUT_ENV_DIR/system.txt"

echo "==> Collecting toolchain versions ..."
{
  echo "# Node & Package Managers"
  (command -v node >/dev/null && node -v) || echo "node: not found"
  (command -v npm  >/dev/null && npm -v ) || echo "npm:  not found"
  (command -v pnpm >/dev/null && pnpm -v) || echo "pnpm: not found"
  (command -v bun  >/dev/null && bun -v ) || echo "bun:  not found"
  echo
  echo "# Framework CLIs"
  npx --yes next --version 2>/dev/null || echo "next: n/a"
  npx --yes tsc  -v        2>/dev/null || echo "tsc:  n/a"
  npx --yes vitest --version 2>/dev/null || echo "vitest: n/a"
  npx --yes jest --version   2>/dev/null || echo "jest: n/a"
  npx --yes prisma -v        2>/dev/null || echo "prisma: n/a"
} > "$OUT_ENV_DIR/tooling.txt"

echo "==> Snapshotting package.json (scripts & deps) ..."
if [[ -f "$ROOT/package.json" ]]; then
  cp "$ROOT/package.json" "$OUT_ENV_DIR/package.json"
  node -e 'const fs=require("fs");const p=require("./package.json");fs.writeFileSync(process.argv[1],JSON.stringify({scripts:p.scripts||{},dependencies:p.dependencies||{},devDependencies:p.devDependencies||{}},null,2))' "$OUT_ENV_DIR/package_scripts_deps.json"
else
  echo "package.json not found" > "$OUT_ENV_DIR/package_scripts_deps.json"
fi

echo "==> Copying common config files ..."
for f in next.config.js tsconfig.json jest.config.js vitest.config.ts tailwind.config.js postcss.config.js; do
  [[ -f "$ROOT/$f" ]] && cp "$ROOT/$f" "$OUT_ENV_DIR/$f" || true
done

echo "==> Prisma snapshot ..."
if [[ -f "$ROOT/prisma/schema.prisma" ]]; then
  mkdir -p "$OUT_ENV_DIR/prisma"
  cp "$ROOT/prisma/schema.prisma" "$OUT_ENV_DIR/prisma/schema.prisma"
  npx --yes prisma migrate status > "$OUT_ENV_DIR/prisma_migrate_status.txt" 2>&1 || true
fi

echo "==> Scanning for DB endpoints (masked) ..."
{
  echo "# Potential database locations (masked)"
  echo "## .env*"
  rg -n --hidden --glob ".env*" -e 'DATABASE_URL|DB_|POSTGRES|MYSQL|SQLITE|SUPABASE|MONGODB' || true
  echo
  echo "## prisma/schema.prisma"
  rg -n 'datasource|provider|url' prisma/schema.prisma 2>/dev/null || true
  echo
  echo "## src/ (config mentions)"
  rg -n -S --glob "src/**" -e 'DATABASE_URL|DB_|POSTGRES|MYSQL|SQLITE|SUPABASE|MONGODB' || true
} > "$OUT_ENV_DIR/db_endpoints_raw.txt"

# Mask secrets/URLs
sed -E 's#(=)[^ \t\r\n]+#=\*\*\*\*#g; s#(url[[:space:]]*=[[:space:]]*")[^"]+#\1****#gi; s#(password|secret|token|key|api)[^=]*=[^ \t\r\n]+#\1=****#gi' \
  "$OUT_ENV_DIR/db_endpoints_raw.txt" > "$OUT_ENV_DIR/db_endpoints.txt" || true
rm -f "$OUT_ENV_DIR/db_endpoints_raw.txt"

echo "==> Capturing environment variables (masked) ..."
printenv | sort | sed -E 's#(^[^=]*(TOKEN|SECRET|PASSWORD|KEY|API|DB|DATABASE|URL)[^=]*=).*#\1****#I' > "$OUT_ENV_DIR/env_public.txt"

echo "==> Ports and processes ..."
(ss -tulpn 2>/dev/null || true) > "$OUT_ENV_DIR/ports.txt"
(ps aux --sort=-%mem 2>/dev/null | head -n 60 || true) > "$OUT_ENV_DIR/processes_top.txt"

echo "==> Repo top-level map ..."
(ls -al 2>/dev/null || true) > "$OUT_ENV_DIR/repo_top_level.txt"

echo "==> Creating .env.share (keys only; NO values) ..."
if [[ -f "$ROOT/.env.example" ]]; then
  cp "$ROOT/.env.example" "$OUT_ENV_DIR/.env.share"
else
  {
    rg -n -o --glob 'src/**' 'process\.env\.[A-Z0-9_]+' 2>/dev/null | sed -E 's/.*process\.env\.//' 
    rg -n --hidden --glob ".env*" '^[A-Z0-9_]+=' 2>/dev/null | sed -E 's/=.*$//'
  } | sort -u | awk '{print $0"="}' > "$OUT_ENV_DIR/.env.share" || true
fi

echo "==> Writing README for GPT ..."
cat > "$OUT_ENV_DIR/README_SHARE_WITH_GPT.md" <<'MD'
# How to use this bundle (for GPT)

This folder contains everything needed to reason about, run, and fix the app **without guessing**:

- system.txt: OS/CPU/memory/disk
- tooling.txt: Node/npm/pnpm/bun + Next/TSC/Vitest/Jest/Prisma versions
- package.json + package_scripts_deps.json: scripts + deps
- Configs: next.config.js, tsconfig.json, tailwind, postcss, jest, vitest (if present)
- Prisma: schema.prisma + migrate status (if present)
- db_endpoints.txt: masked hints to DB locations
- env_public.txt: masked environment variables
- .env.share: keys template (NO values)
- ports.txt / processes_top.txt
- repo_top_level.txt

## Typical run flow
1) Install deps: `pnpm install` (or `npm install`)
2) Dev: `pnpm dev` (or `npm run dev`)
3) Test: `pnpm test` / `pnpm vitest` / `pnpm jest`
4) Lint/Build: `pnpm lint && pnpm build`
5) Prisma (if used):
   - `pnpm prisma generate`
   - `pnpm prisma migrate dev` (DB required; ask user for real .env values)

If anything fails, propose patch diffs for files in `src/`, `prisma/`, or config files, then show ready-to-run git commands.
MD

echo "==> Zipping environment report to $ZIP_ENV ..."
( cd "$OUT_DIR" && zip -r "$(basename "$ZIP_ENV")" "$(basename "$OUT_ENV_DIR")" >/dev/null )

echo "==> Zipping code bundle to $ZIP_CODE ..."
# Tailored include/exclude for typical TS/Next projects
zip -r "$ZIP_CODE" \
  src public docs scripts prisma tests \
  *.md *.js *.ts *.json *.yaml *.yml \
  next.config.js tailwind.config.js postcss.config.js jest.config.js vitest.config.ts \
  --exclude "node_modules/*" ".git/*" ".next/*" ".vscode/*" ".github/*" ".vercel/*" \
            "*.log" "*.tsbuildinfo" ".env*" "build-output.log" "test-output.log" "temp.json" "latestEnd" >/dev/null

echo
echo "==> Quick peek: $(basename "$ZIP_CODE")"
unzip -l "$ZIP_CODE" | head -n 40 || true
echo "..."
echo
echo "==> Quick peek: $(basename "$ZIP_ENV")"
unzip -l "$ZIP_ENV" | head -n 40 || true
echo "..."
echo
echo "==> Done."
echo "Artifacts saved in: $OUT_DIR"
echo "  - $(basename "$ZIP_CODE")"
echo "  - $(basename "$ZIP_ENV")"
