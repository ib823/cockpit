// Re-export types from core.ts to maintain backward compatibility
export type { Phase, Resource, Holiday, ClientProfile } from "./core";
