Upload this folder with your code so GPT understands your environment:
- system.txt, tooling.txt
- package.json, package_scripts_deps.json
- configs (tsconfig, next.config, tailwind, jest, vitest)
- prisma schema/migrations (if any)
- masked env + db endpoints
- ports/processes
